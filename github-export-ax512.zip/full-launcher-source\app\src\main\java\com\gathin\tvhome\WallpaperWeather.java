package com.gathin.tvhome;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * wallpaper_weather: which group of a rotating wallpaper collection fits the weather block's condition. The groups
 * come from a theme's {@code wallpaper_weather_groups} (config.json), mapping a condition to file names in
 * {@code wallpapers/}: clear, cloudy, fog, rain, snow, storm and night. A condition with no group of its own falls
 * back to the night group while it is dark and to the clear group by day, so a set of only day and night pictures
 * still changes over the day. At night a clear sky is the night group; rain, snow and storms keep their own whatever
 * the hour. Nothing is drawn: the rotation reuses the pictures already in {@code wallpapers/}, like
 * {@link WallpaperMood} does for the time of day.
 */
final class WallpaperWeather {
    static final String CLEAR = "clear", CLOUDY = "cloudy", FOG = "fog", RAIN = "rain", SNOW = "snow";
    static final String STORM = "storm", NIGHT = "night";
    static final String[] ALL = {CLEAR, CLOUDY, FOG, RAIN, SNOW, STORM, NIGHT};
    /** The weather code before the first fetch, or after one that failed: no condition, so the whole collection. */
    static final int UNKNOWN = Integer.MIN_VALUE;

    private WallpaperWeather() {
    }

    /**
     * The group a WMO weather code belongs to, or null when it is unknown. Rain covers drizzle and showers, and
     * thunderstorms (which usually pour too) are their own group so a set can flash a stormy picture.
     */
    static String condition(int code) {
        switch (code) {
            case 0:
                return CLEAR;
            case 1:
            case 2:
            case 3:
                return CLOUDY;
            case 45:
            case 48:
                return FOG;
            case 51:
            case 53:
            case 55:
            case 56:
            case 57:
            case 61:
            case 63:
            case 65:
            case 66:
            case 67:
            case 80:
            case 81:
            case 82:
                return RAIN;
            case 71:
            case 73:
            case 75:
            case 77:
            case 85:
            case 86:
                return SNOW;
            case 95:
            case 96:
            case 99:
                return STORM;
            default:
                return null;
        }
    }

    /**
     * The pictures the rotation picks from now: the group that fits the weather. A condition with no group of its
     * own falls back to the night group while it is dark and to the clear group by day, so a set of only day and
     * night pictures still changes over the day instead of showing a night picture at noon. A clear sky at night is
     * the night group; every other condition keeps its own. The whole collection when even the fallback is missing.
     */
    static List<File> select(List<File> all, Map<String, Set<String>> groups, int code, boolean night) {
        if (groups.isEmpty()) return all;
        String key = condition(code);
        if (night && (key == null || CLEAR.equals(key))) key = NIGHT;
        List<File> group = group(all, groups, key);
        if (!group.isEmpty()) return group;
        List<File> fallback = group(all, groups, night ? NIGHT : CLEAR);
        return fallback.isEmpty() ? all : fallback;
    }

    /** The collection's pictures named in the group, in the collection's order; empty when the group has none. */
    private static List<File> group(List<File> all, Map<String, Set<String>> groups, String key) {
        Set<String> names = key == null ? null : groups.get(key);
        List<File> out = new ArrayList<>();
        if (names == null) return out;
        for (File file : all) if (names.contains(file.getName())) out.add(file);
        return out;
    }
}
