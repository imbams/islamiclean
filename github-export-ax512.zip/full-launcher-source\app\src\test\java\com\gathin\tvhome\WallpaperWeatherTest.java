package com.gathin.tvhome;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

/** Plain JVM tests for wallpaper_weather: the WMO code's condition and the pictures it picks from. */
public class WallpaperWeatherTest {

    @Test
    public void conditionGroupsTheWmoCodes() {
        assertEquals(WallpaperWeather.CLEAR, WallpaperWeather.condition(0));
        assertEquals(WallpaperWeather.CLOUDY, WallpaperWeather.condition(2));
        assertEquals(WallpaperWeather.FOG, WallpaperWeather.condition(45));
        assertEquals(WallpaperWeather.FOG, WallpaperWeather.condition(48));
        assertEquals(WallpaperWeather.RAIN, WallpaperWeather.condition(51));   // drizzle
        assertEquals(WallpaperWeather.RAIN, WallpaperWeather.condition(65));   // heavy rain
        assertEquals(WallpaperWeather.RAIN, WallpaperWeather.condition(82));   // showers
        assertEquals(WallpaperWeather.SNOW, WallpaperWeather.condition(75));
        assertEquals(WallpaperWeather.SNOW, WallpaperWeather.condition(86));
        assertEquals(WallpaperWeather.STORM, WallpaperWeather.condition(95));
        assertEquals(WallpaperWeather.STORM, WallpaperWeather.condition(99));
        assertNull(WallpaperWeather.condition(WallpaperWeather.UNKNOWN));
        assertNull(WallpaperWeather.condition(42));
    }

    private static List<File> files(String... names) {
        List<File> out = new ArrayList<>();
        for (String name : names) out.add(new File("/walls", name));
        return out;
    }

    private static List<String> names(List<File> files) {
        List<String> out = new ArrayList<>();
        for (File f : files) out.add(f.getName());
        return out;
    }

    private static Map<String, Set<String>> groups() {
        Map<String, Set<String>> groups = new HashMap<>();
        groups.put(WallpaperWeather.CLEAR, new HashSet<>(Collections.singletonList("day.jpg")));
        groups.put(WallpaperWeather.NIGHT, new HashSet<>(Collections.singletonList("night.jpg")));
        groups.put(WallpaperWeather.RAIN, new HashSet<>(Arrays.asList("rain1.jpg", "rain2.jpg")));
        return groups;
    }

    @Test
    public void selectFollowsTheCondition() {
        List<File> all = files("day.jpg", "night.jpg", "rain1.jpg", "rain2.jpg", "other.jpg");
        assertEquals(Collections.singletonList("day.jpg"), names(WallpaperWeather.select(all, groups(), 0, false)));
        assertEquals(Arrays.asList("rain1.jpg", "rain2.jpg"),
                names(WallpaperWeather.select(all, groups(), 61, false)));
    }

    @Test
    public void clearAtNightUsesTheNightGroup() {
        List<File> all = files("day.jpg", "night.jpg", "rain1.jpg", "rain2.jpg");
        assertEquals(Collections.singletonList("night.jpg"), names(WallpaperWeather.select(all, groups(), 0, true)));
        // rain keeps its own group at night
        assertEquals(Arrays.asList("rain1.jpg", "rain2.jpg"),
                names(WallpaperWeather.select(all, groups(), 65, true)));
    }

    @Test
    public void missingGroupFallsBackToNightOrClear() {
        List<File> all = files("day.jpg", "night.jpg", "rain1.jpg", "rain2.jpg");
        // snow has no group: the clear group by day, the night group while dark
        assertEquals(Collections.singletonList("day.jpg"), names(WallpaperWeather.select(all, groups(), 71, false)));
        assertEquals(Collections.singletonList("night.jpg"), names(WallpaperWeather.select(all, groups(), 71, true)));
        // unknown weather follows the same fallback
        assertEquals(Collections.singletonList("night.jpg"),
                names(WallpaperWeather.select(all, groups(), WallpaperWeather.UNKNOWN, true)));
        assertEquals(Collections.singletonList("day.jpg"),
                names(WallpaperWeather.select(all, groups(), WallpaperWeather.UNKNOWN, false)));
    }

    @Test
    public void missingFallbackGroupUsesTheWholeCollection() {
        List<File> all = files("night.jpg", "other.jpg");
        Map<String, Set<String>> onlyNight = new HashMap<>();
        onlyNight.put(WallpaperWeather.NIGHT, new HashSet<>(Collections.singletonList("night.jpg")));
        // a cloudy day has no clear group to fall back to
        assertEquals(all, WallpaperWeather.select(all, onlyNight, 3, false));
        assertEquals(Collections.singletonList("night.jpg"), names(WallpaperWeather.select(all, onlyNight, 3, true)));
        // no groups at all: everything
        assertEquals(all, WallpaperWeather.select(all, Collections.emptyMap(), 0, false));
    }
}
