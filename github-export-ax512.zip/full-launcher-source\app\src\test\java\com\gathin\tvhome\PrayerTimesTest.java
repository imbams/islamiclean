package com.gathin.tvhome;

import org.junit.Test;

import java.time.LocalDate;
import java.time.ZoneId;

import static org.junit.Assert.assertEquals;

/** The Bantul schedule against Kemenag's published table, and the +8 Muhammadiyah Subuh. */
public class PrayerTimesTest {

    private static final ZoneId WIB = ZoneId.of("Asia/Jakarta");
    /** Kemenag's place for Kab. Bantul. */
    private static final double LAT = -7.8856, LON = 110.3289;
    private static final int SUBUH_ADJUST = 8;

    private static int[] bantul(int year, int month, int day) {
        return PrayerTimes.forDate(LocalDate.of(year, month, day), LAT, LON, WIB, SUBUH_ADJUST);
    }

    private static int at(int hour, int minute) {
        return hour * 60 + minute;
    }

    @Test
    public void matchesKemenagBantulOn12November2026() {
        // Kemenag: Subuh 03:49, Dzuhur 11:26, Ashar 14:45, Maghrib 17:40, Isya 18:53.
        int[] t = bantul(2026, 11, 12);
        assertEquals(at(3, 57), t[PrayerTimes.SUBUH]);      // 03:49 + the 8-minute Muhammadiyah shift
        assertEquals(at(11, 26), t[PrayerTimes.DZUHUR]);
        assertEquals(at(14, 45), t[PrayerTimes.ASHAR]);
        assertEquals(at(17, 40), t[PrayerTimes.MAGHRIB]);
        assertEquals(at(18, 53), t[PrayerTimes.ISYA]);
    }

    @Test
    public void matchesKemenagBantulOn13November2026() {
        // Kemenag: Subuh 03:49, Dzuhur 11:26, Ashar 14:46, Maghrib 17:40, Isya 18:53.
        int[] t = bantul(2026, 11, 13);
        assertEquals(at(3, 57), t[PrayerTimes.SUBUH]);
        assertEquals(at(11, 26), t[PrayerTimes.DZUHUR]);
        assertEquals(at(14, 46), t[PrayerTimes.ASHAR]);
        assertEquals(at(17, 40), t[PrayerTimes.MAGHRIB]);
        assertEquals(at(18, 53), t[PrayerTimes.ISYA]);
    }

    @Test
    public void theAdjustMovesOnlySubuh() {
        int[] plain = PrayerTimes.forDate(LocalDate.of(2026, 11, 12), LAT, LON, WIB, 0);
        int[] shifted = bantul(2026, 11, 12);
        assertEquals(plain[PrayerTimes.SUBUH] + SUBUH_ADJUST, shifted[PrayerTimes.SUBUH]);
        for (int i = 1; i < PrayerTimes.COUNT; i++) assertEquals(plain[i], shifted[i]);
    }

    @Test
    public void nextPrayerRollsOverToTomorrowsSubuh() {
        int[] t = bantul(2026, 11, 12);
        assertEquals(PrayerTimes.SUBUH, PrayerTimes.next(t, at(3, 0) * 60));
        assertEquals(PrayerTimes.DZUHUR, PrayerTimes.next(t, at(3, 57) * 60));
        assertEquals(PrayerTimes.ISYA, PrayerTimes.next(t, at(17, 41) * 60));
        assertEquals(PrayerTimes.SUBUH, PrayerTimes.next(t, at(23, 0) * 60));
    }
}
