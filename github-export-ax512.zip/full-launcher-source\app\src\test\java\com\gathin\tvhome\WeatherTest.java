package com.gathin.tvhome;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/** The WMO condition and US AQI category mappings. */
public class WeatherTest {

    @Test
    public void wmoCodesMapToConditions() {
        assertEquals(R.string.weather_clear, Weather.describe(0));
        assertEquals(R.string.weather_mainly_clear, Weather.describe(1));
        assertEquals(R.string.weather_partly_cloudy, Weather.describe(2));
        assertEquals(R.string.weather_overcast, Weather.describe(3));
        assertEquals(R.string.weather_fog, Weather.describe(48));
        assertEquals(R.string.weather_drizzle, Weather.describe(55));
        assertEquals(R.string.weather_rain, Weather.describe(65));
        assertEquals(R.string.weather_snow, Weather.describe(75));
        assertEquals(R.string.weather_showers, Weather.describe(82));
        assertEquals(R.string.weather_thunderstorm, Weather.describe(95));
        assertEquals(R.string.weather_unknown, Weather.describe(42));
    }

    @Test
    public void aqiCategoriesFollowTheUsBands() {
        assertEquals(R.string.aqi_good, Weather.aqiCategory(0));
        assertEquals(R.string.aqi_good, Weather.aqiCategory(50));
        assertEquals(R.string.aqi_moderate, Weather.aqiCategory(51));
        assertEquals(R.string.aqi_moderate, Weather.aqiCategory(100));
        assertEquals(R.string.aqi_unhealthy_sensitive, Weather.aqiCategory(109));
        assertEquals(R.string.aqi_unhealthy_sensitive, Weather.aqiCategory(150));
        assertEquals(R.string.aqi_unhealthy, Weather.aqiCategory(151));
        assertEquals(R.string.aqi_unhealthy, Weather.aqiCategory(200));
        assertEquals(R.string.aqi_very_unhealthy, Weather.aqiCategory(300));
        assertEquals(R.string.aqi_hazardous, Weather.aqiCategory(301));
    }
}
