package com.gathin.tvhome;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;

import org.junit.Test;

/** The pasaran cycle, anchored on 1945-08-17 (a Jumat Legi) and checked against published calendars. */
public class WetonTest {

    @Test
    public void pasaranMatchesTheAnchorAndKnownDates() {
        assertEquals("Legi", Weton.pasaran(LocalDate.of(1945, 8, 17)));
        assertEquals("Legi", Weton.pasaran(LocalDate.of(2025, 8, 17)));
        assertEquals("Pon", Weton.pasaran(LocalDate.of(2026, 11, 12)));
        assertEquals("Wage", Weton.pasaran(LocalDate.of(2026, 11, 13)));
        assertEquals("Kliwon", Weton.pasaran(LocalDate.of(2026, 11, 14)));
        assertEquals("Legi", Weton.pasaran(LocalDate.of(2026, 11, 15)));
    }

    @Test
    public void pasaranWrapsAcrossTheCycle() {
        LocalDate start = LocalDate.of(2026, 11, 12);
        String[] cycle = {"Pon", "Wage", "Kliwon", "Legi", "Pahing"};
        for (int i = 0; i < 10; i++) {
            assertEquals(cycle[i % cycle.length], Weton.pasaran(start.plusDays(i)));
        }
    }
}
