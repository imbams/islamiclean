package com.gathin.tvhome;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.time.LocalDate;

import org.junit.Test;

/** KHGT month starts and the three countdowns, checked against khgt.muhammadiyah.or.id. */
public class HijriTest {

    @Test
    public void dateLabelMatchesThePublishedCalendar() {
        assertEquals("3 Jumadilakhir 1448 H", Hijri.dateLabel(LocalDate.of(2026, 11, 12)));
        assertEquals("1 Jumadilakhir 1448 H", Hijri.dateLabel(LocalDate.of(2026, 11, 10)));
        assertEquals("29 Jumadilawal 1448 H", Hijri.dateLabel(LocalDate.of(2026, 11, 9)));
        assertEquals("1 Ramadan 1448 H", Hijri.dateLabel(LocalDate.of(2027, 2, 8)));
    }

    @Test
    public void monthStartsFollowThePublishedTable() {
        assertEquals(LocalDate.of(2026, 6, 16), Hijri.start(1448, 1));
        assertEquals(LocalDate.of(2027, 2, 8), Hijri.start(1448, Hijri.RAMADAN));
        assertEquals(LocalDate.of(2027, 3, 9), Hijri.start(1448, Hijri.SYAWAL));
        assertEquals(LocalDate.of(2028, 1, 28), Hijri.start(1449, Hijri.RAMADAN));
        assertEquals(LocalDate.of(2029, 1, 16), Hijri.start(1450, Hijri.RAMADAN));
    }

    @Test
    public void eventsCountFromToday() {
        LocalDate today = LocalDate.of(2026, 11, 12);
        Hijri.Event ramadan = Hijri.nextEvent(today, Hijri.RAMADAN, 1);
        assertNotNull(ramadan);
        assertEquals(LocalDate.of(2027, 2, 8), ramadan.date);
        assertEquals(1448, ramadan.year);
        assertEquals(88, ramadan.days);

        Hijri.Event fitri = Hijri.nextEvent(today, Hijri.SYAWAL, 1);
        assertNotNull(fitri);
        assertEquals(LocalDate.of(2027, 3, 9), fitri.date);
        assertEquals(117, fitri.days);

        Hijri.Event adha = Hijri.nextEvent(today, Hijri.ZULHIJAH, 10);
        assertNotNull(adha);
        assertEquals(LocalDate.of(2027, 5, 16), adha.date);
        assertEquals(185, adha.days);

        Hijri.Event muharram = Hijri.nextEvent(today, Hijri.MUHARAM, 1);
        assertNotNull(muharram);
        assertEquals(LocalDate.of(2027, 6, 6), muharram.date);
        assertEquals(1449, muharram.year);
        assertEquals(206, muharram.days);
    }

    @Test
    public void todayIsZeroDaysAndPastEventsRollToNextYear() {
        Hijri.Event onTheDay = Hijri.nextEvent(LocalDate.of(2027, 2, 8), Hijri.RAMADAN, 1);
        assertNotNull(onTheDay);
        assertEquals(1448, onTheDay.year);
        assertEquals(0, onTheDay.days);

        Hijri.Event next = Hijri.nextEvent(LocalDate.of(2027, 2, 9), Hijri.RAMADAN, 1);
        assertNotNull(next);
        assertEquals(1449, next.year);
        assertEquals(LocalDate.of(2028, 1, 28), next.date);
    }

    @Test
    public void outsideTheTableThereIsNoGuess() {
        assertNull(Hijri.dateLabel(LocalDate.of(2035, 1, 1)));
        assertNull(Hijri.nextEvent(LocalDate.of(2035, 1, 1), Hijri.RAMADAN, 1));
    }

    @Test
    public void shortDateUsesIndonesianMonthNames() {
        assertEquals("8 Feb 2027", Hijri.shortDate(LocalDate.of(2027, 2, 8)));
        assertEquals("16 Mei 2027", Hijri.shortDate(LocalDate.of(2027, 5, 16)));
    }
}
